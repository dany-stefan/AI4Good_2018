local tagger = {}

tagger.Tagger = require('onmt.tagger.Tagger')

return tagger
