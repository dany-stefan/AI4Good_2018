local lm = {}

lm.LM = require('onmt.lm.LM')

return lm
